.. STON documentation master file, created by
   sphinx-quickstart on Fri Jun 13 16:37:06 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.



Getting Started STON-STON
================================

Contents:

.. toctree::
   :maxdepth: 2

GETTING STARTED!!


